1. Uso de variables

Cambio: Reemplacé el comando set /p de CMD por Read-Host en PowerShell.
Razón: En CMD, el comando set /p se utiliza para leer la entrada del usuario, mientras que en PowerShell, el equivalente es Read-Host. Este cambio permite que PowerShell reciba las elecciones del usuario de manera correcta.
Ejemplo:

CMD: set /p choice1=Elige 1 o 2:
PowerShell: $choice1 = Read-Host "Elige 1 o 2"

2. Estructuras de control (Condicionales y saltos)

Cambio: Cambié las sentencias if y goto de CMD por estructuras de control en PowerShell usando if y goto.
Razón: PowerShell también soporta estructuras condicionales if, pero las etiquetas goto no son tan comunes en PowerShell. En su lugar, utilizamos etiquetas con un flujo controlado (en este caso, goto) para simular el comportamiento.
Ejemplo:

CMD: if "%choice1%"=="1" goto Biblioteca
PowerShell: if ($choice1 -eq "1") { goto Biblioteca }

3. Salidas y colores

Cambio: Reemplacé los comandos color de CMD por $Host.UI.RawUI.ForegroundColor de PowerShell para cambiar el color del texto.
Razón: PowerShell no usa el comando color de CMD. En su lugar, se puede cambiar el color del texto utilizando $Host.UI.RawUI.ForegroundColor, lo que permite personalizar los colores del texto de forma más sencilla.
Ejemplo:

CMD: color 06
PowerShell: $Host.UI.RawUI.ForegroundColor = 'Yellow'

4. Limpieza de la pantalla

Cambio: Reemplacé cls de CMD por Clear-Host en PowerShell.
Razón: cls es específico de CMD y en PowerShell el comando equivalente para limpiar la pantalla es Clear-Host.
Ejemplo:

CMD: cls
PowerShell: Clear-Host

5. Pausa antes de salir

Cambio: Usé Pause en CMD, pero en PowerShell, el equivalente es Pause también, ya que es compatible.
Razón: PowerShell también soporta el comando Pause, que permite que el programa espere la entrada del usuario antes de cerrar la ventana.
Ejemplo:

CMD: pause
PowerShell: Pause

6. Saltos de flujo (Goto)

Cambio: Reemplacé las etiquetas goto de CMD por etiquetas similares en PowerShell.
Razón: PowerShell soporta el uso de etiquetas y se puede realizar saltos de flujo mediante el comando goto. Las etiquetas en PowerShell deben estar precedidas por un : (dos puntos), igual que en CMD.
Ejemplo:

CMD: goto Biblioteca
PowerShell: goto Biblioteca

7. Mensajes al usuario

Cambio: Usé Write-Host para mostrar mensajes en PowerShell, en lugar de echo de CMD.
Razón: PowerShell usa Write-Host para imprimir mensajes en la consola, mientras que en CMD se utiliza echo. Es una forma estándar de mostrar salidas en PowerShell.
Ejemplo:

CMD: echo En la biblioteca, encuentras un pergamino...
PowerShell: Write-Host "En la biblioteca, encuentras un pergamino..."

8. Control de flujo de la historia (funciones y secuencias)

Cambio: Utilicé goto con etiquetas para controlar el flujo de la historia de forma similar a cómo funcionaba en CMD.
Razón: Aunque PowerShell generalmente no utiliza goto, en este caso lo usé para emular la lógica del juego de CMD, donde el flujo depende de las decisiones del usuario.

9. hemos cambiado las letras con tilde porque la salida era mal

10. Se añadió un bucle while para asegurarse de que el usuario elija "1" o "2", repitiendo la pregunta si ingresa algo incorrecto.

    Escribí una función llamada Get-Choice y descubrí que causaba un conflicto de nombre, cambié el nombre y funcionó sin ningún problema.



